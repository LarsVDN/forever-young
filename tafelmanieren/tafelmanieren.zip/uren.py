for i in range(0, 2):
    for y in range(1, 13):
        if i == 0:
            print(str(y) + " AM")
        else:
            print(str(y) + " PM")
