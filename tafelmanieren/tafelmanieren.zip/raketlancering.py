for i in range(31, 0, -1):
    print(i)
